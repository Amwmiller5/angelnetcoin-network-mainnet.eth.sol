var PlantShop = artifacts.require("PlantShop");

module.exports = function(deployer) {
  deployer.deploy(PlantShop);
};
