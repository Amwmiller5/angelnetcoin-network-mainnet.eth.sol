import React from 'react'

export const Wrapper = ({ children }) =>
  <div style={{ padding: '20px' }}>
    {children}
  </div>
