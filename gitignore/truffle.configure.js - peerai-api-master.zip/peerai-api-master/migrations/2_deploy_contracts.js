var Peerism = artifacts.require("./Peerism.sol");

module.exports = function(deployer) {
  deployer.deploy(Peerism);
};
