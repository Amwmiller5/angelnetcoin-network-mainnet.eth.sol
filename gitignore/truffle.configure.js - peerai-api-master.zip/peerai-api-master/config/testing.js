module.exports = {
  logging: false,
  db: {
    url: 'mongodb://localhost/peerai-test'
  },
  port: 7111
};