module.exports = {
  logging: true,
  db: {
    url: 'mongodb://localhost/peerai'
  },
  port: 7000
};