#!/usr/bin/env bash
rm -rf source/client/src/contracts
docker-compose -f docker-compose-dev.yml up