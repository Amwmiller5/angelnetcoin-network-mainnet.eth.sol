const MyGallery = artifacts.require("MyGallery");

module.exports = function(deployer) {
  deployer.deploy(MyGallery);
};
