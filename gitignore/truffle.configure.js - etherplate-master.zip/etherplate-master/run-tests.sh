#! /bin/sh
npm test && truffle test
