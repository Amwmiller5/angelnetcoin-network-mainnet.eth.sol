## [azure-simple-marketplace-box] Changelog

<a name="0.2.0"></a>
# 0.2.0 (2019-11-18)

*Features*
* Update Solidity version to ^0.5.0
* Add full unit tests grouped according to transition functions
* Use “truffle-assertions” to test reverts and emit
* Update deprecated "truffle-hdwallet-provider" version
* Changes some styles
* Remove WorkBench base class since it is WB specific
* Add License, Contributing and Changelog markdown files