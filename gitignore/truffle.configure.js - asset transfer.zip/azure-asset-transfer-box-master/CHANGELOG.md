## [azure-asset-transfer] Changelog

<a name="0.2.0"></a>
# 0.2.0 (2019-11-08)

*Features*
* Update Solidity version to ^0.5.0
* Add full unit tests grouped according to transition functions
* Use “truffle-assertions” to test reverts and emit
* Update deprecated "truffle-hdwallet-provider" version
* Changes some styles
* Remove WorkBench base class since it is WB specific
* Resize media picture so that words are not distorted

<a name="0.1.0"></a>
# 0.1.0 (2019-08-04)

*Features*
* Basic functionality